# Civic Sahayak — Officer Console

Officer-facing dashboard for **Civic Sahayak**, a multilingual civic complaint
management system for Bengaluru Zone 4. This is the half of the product
government staff use to triage, classify, and resolve citizen complaints
routed to their department.

A self-contained, single-file HTML/CSS/JS prototype — no build step, no
dependencies beyond a Google Fonts import. Open `index.html` in any browser
to run it.

## Screens

1. **Login** — officer sign-in with department selection (Water, Roads,
   Electricity, Sanitation, Drainage).
2. **Ticket queue** — complaints routed to the officer's department, with
   AI-generated one-line summaries, urgency and SLA-status filters, and an
   SLA countdown indicator per ticket.
3. **Ticket detail** — original complaint text (in the citizen's language)
   with AI translation, AI classification and confidence score, a status
   timeline, and linked sub-tickets for complaints split across multiple
   departments.
4. **Analytics** — open/resolved/breached counts, SLA-status breakdown,
   a 7-day reporting trend, and a ward-level complaint density view.

## Running it

Just open `index.html` in a browser — no server required. To edit and
preview live, drop it into CodePen, StackBlitz, or JSFiddle as a single
HTML file, or serve it locally:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Status

Prototype / design mockup. All data is hard-coded sample data — there is no
backend, and actions (status changes, sending citizen updates) only update
local in-memory state for demo purposes.

## Related

Pairs with the citizen-facing complaint reporting app (report + track a
complaint) built separately by another contributor on this project.
